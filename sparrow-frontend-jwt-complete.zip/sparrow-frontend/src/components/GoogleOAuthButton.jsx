import React from 'react';
import './styles/modern-theme.css';

/**
 * Google OAuth Sign-In Button
 * 
 * This button redirects users to the backend OIDC endpoint,
 * which handles the entire Google authentication flow.
 * 
 * Flow:
 * 1. User clicks button → redirects to /auth/google
 * 2. Backend redirects to Google's consent screen
 * 3. User logs in at Google
 * 4. Google redirects back to backend with auth code
 * 5. Backend exchanges code for tokens, creates session
 * 6. Backend redirects to frontend /auth/success route
 * 7. Frontend fetches user data and redirects to chat
 */
const GoogleOAuthButton = ({ text = 'Continue with Google', className = '' }) => {
  const handleGoogleLogin = () => {
    // Redirect to backend OIDC endpoint
    // Backend URL should match your .env BACKEND_URL or default to localhost:5000
    const backendUrl = process.env.REACT_APP_BACKEND_URL || 'http://localhost:5000';
    window.location.href = `${backendUrl}/auth/google`;
  };

  return (
    <button 
      type="button" 
      onClick={handleGoogleLogin} 
      className={`google-oauth-button ${className}`}
    >
      <svg 
        className="google-icon" 
        viewBox="0 0 24 24" 
        width="20" 
        height="20"
      >
        <path
          fill="#4285F4"
          d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
        />
        <path
          fill="#34A853"
          d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
        />
        <path
          fill="#FBBC05"
          d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
        />
        <path
          fill="#EA4335"
          d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
        />
      </svg>
      <span className="google-text">{text}</span>
    </button>
  );
};

export default GoogleOAuthButton;

